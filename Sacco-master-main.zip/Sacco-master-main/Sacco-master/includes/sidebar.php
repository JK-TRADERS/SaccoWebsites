<div style="width:20%;background-color:lightgrey;border:5px solid red;height:350px;float:right;">
    <marquee>My Sidebar</marquee>
</div>