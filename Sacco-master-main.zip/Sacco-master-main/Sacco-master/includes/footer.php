<br><br>

<br><br>
</div>

    <?php
	    include "sidebar.php";
	?>
<br>
</div>
All rights reserved. Copyright &copy <?php echo date("Y")?>.
<br><br>
</center>
</body>
</html>