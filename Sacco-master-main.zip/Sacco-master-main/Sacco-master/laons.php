<?php
include "includes/header.php";
?>

Welcome to Loans


<?php
include"includes/footer.php";
?>