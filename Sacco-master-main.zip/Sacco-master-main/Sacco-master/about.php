<?php
include "includes/header.php"
?>
Welcome to About page
<?php
include "includes/footer.php"
?>