<?php
include "includes/header.php"
?>
Welcome to Profile page
<?php
include "includes/footer.php"
?>