<?php
include "includes/header.php"
?>
Welcome to Dashboard
<?php
include "includes/footer.php"
?>